INSERT INTO ALUNO (id, matricula, nome, cpf, email, fone)
VALUES (1, '2022123456', 'João', '507.088.970-29', 'joao@mail.com', '(83) 9999-9999'),
       (2, '2022123456', 'Maria', '599.899.850-22', 'maria@mail.com', '(83) 9999-9999'),
       (3, '2022123456', 'Fernanda', '274.099.790-62', 'fernanda@mail.com', '(83) 9999-9999');