package com.uniesp.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppDemoTests {

	@Test
	void contextLoads() {
	}

}
